#ifndef IDTLOADER_H_
#define IDTLOADER_H_

void loadIDT();	

#endif
