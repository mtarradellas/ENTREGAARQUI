/* 
	****** 	Module for Time	******
*/


#ifndef TIMEMODULE_H
#define TIMEMODULE_H

unsigned int getHour();

unsigned int getMinute();

unsigned int getSecond();

void wait(int n);

#endif